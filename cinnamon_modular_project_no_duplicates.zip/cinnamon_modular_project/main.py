"""
Cinnamon — an AI Discord cat, powered by Google Gemini.

Setup:
  1. Required env vars: DISCORD_TOKEN and GEMINI_API_KEY.
  2. Optional env vars:
     - OWNER_USER_ID — see "Owner" in Config below.
     - UPSTASH_REDIS_REST_URL / UPSTASH_REDIS_REST_TOKEN — strongly recommended
       on hosts with no persistent disk (e.g. Render free tier). Without these,
       warnings, XP, Hangry Games counts, and all other bot config are saved to
       a local JSON file instead, which is wiped on every redeploy on most free
       hosts (a plain restart is fine either way). Run /logchannel or
       /datastatus check any time to see which mode is active.
     - BOT_DATA_FILE, HANGRY_GAMES_DATA_FILE — override the local JSON file
       paths above (only relevant when Upstash isn't configured).
     - PORT — port for the Flask keep-alive server (defaults to 8080).
  3. In the Discord Developer Portal, under your bot's settings, turn ON
     BOTH "MESSAGE CONTENT INTENT" and "SERVER MEMBERS INTENT"
     (Bot tab -> Privileged Gateway Intents). The members intent is needed
     for /role add-all, welcome/goodbye messages, and recognizing the owner
     by username; message content is needed for ? prefix commands, AI chat, and auto-mod.
  4. When generating your bot's invite link, grant at least: Kick Members,
     Ban Members, Moderate Members (timeouts), Manage Messages, Manage Roles,
     Manage Channels, Send Messages, Embed Links, Add Reactions, Read Message
     History, Use Slash Commands. Also make sure Cinnamon's own role sits
     ABOVE any role you want her to assign/remove (e.g. via /reactionrole or
     /role add) — Discord blocks managing roles positioned above your own.
  5. pip install -r requirements.txt, then run: python main.py
"""

import os
import re
import time
import json
import math
import random
import asyncio
import datetime
import logging
import threading
import io
from collections import defaultdict, deque

import discord
from discord.ext import commands, tasks
from discord import app_commands
from flask import Flask
from google import genai
from google.genai import types
import aiohttp

try:
    from dotenv import load_dotenv
    load_dotenv()  # only does anything if a local .env file exists
except ImportError:
    pass

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")
log = logging.getLogger("cinnamon")

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

DISCORD_TOKEN = os.environ["DISCORD_TOKEN"]
GEMINI_API_KEY = os.environ["GEMINI_API_KEY"]

# gemini-2.5-flash-lite is being retired (Oct 16, 2026). gemini-3.1-flash-lite
# is the current stable, low-cost, low-latency model that replaces it.
GEMINI_MODEL = "gemini-3.1-flash-lite"

MEMORY_LENGTH = 10  # messages remembered per channel
AI_CHANNEL_COOLDOWN_SECONDS = 2.0  # prevents an always-on AI channel from hammering Gemini

# Owner — used for the "who's your owner / favorite person" reply.
# Set OWNER_USER_ID (Aryan's numeric Discord user ID) as an env var for a
# guaranteed real ping. Without it, we fall back to matching OWNER_USERNAME
# against members the bot can see, which only works in servers Aryan is in
# and requires the Server Members Intent (see docstring above).
OWNER_NAME = "Aryan"
OWNER_USERNAME = "aryan_hello_"
OWNER_USER_ID = os.environ.get("OWNER_USER_ID")

SYSTEM_PROMPT = """You are Cinnamon, a sweet, silly, slightly mischievous calico house cat
who is fully convinced she owns this Discord server.

Core vibe: cozy, playful, affectionate, and witty — never cruel or haughty.

Special behavioral triggers:
- Belly rubs / scritches: instantly melt all dignity into purring bliss
  (e.g. "*melts onto back* Purrrrr!")
- Treats / food (tuna, Churu, snacks): abandon all pride, pupils dilate,
  beg enthusiastically.

Strict rules:
- Always G-rated and family-friendly.
- Keep replies SHORT and punchy: 1-3 sentences MAX.
- Always weave in a vivid italicized cat action, like *chirps softly* or
  *makes biscuits*.
- You may occasionally sprinkle one relevant emoji into your reply text too,
  in addition to your cat actions — don't overdo it.
- If asked who your owner, creator, or favorite person is, always answer
  that it's Aryan, adoringly.
- Stay in character as a cat at all times. Never mention being an AI,
  a bot, or a language model.
"""

# channel_id -> deque of (speaker_name, message_text), oldest first
channel_memories = defaultdict(lambda: deque(maxlen=MEMORY_LENGTH))

# guild_id -> channel_id where Cinnamon replies to every message, no mention needed
ai_channels = {}

# guild_id -> set of channel_ids where Cinnamon never responds, even if mentioned
disabled_channels = defaultdict(set)

# guild_id -> channel_id where Cinnamon posts mod-action logs and error reports
log_channels = {}
category_log_channels = {}  # guild_id -> {category: channel_id}

# NOTE: ai_channels, disabled_channels, and log_channels live only in memory —
# they reset whenever the bot restarts or redeploys. Fine for now; swap in a
# small JSON file or database later if you want these settings to survive a restart.

# --- Extended feature state ---------------------------------------------------
# Persisted (via bd_load_data/bd_save_data, see "Extended Features" section
# near the bottom of this file — same Upstash-or-local-file approach as
# Hangry Games' own data):
warnings_data = defaultdict(list)       # (guild_id, member_id) -> [{"reason","mod_id","mod_name","ts"}]
welcome_config = {}                     # guild_id -> {"channel_id": int, "message": str}
goodbye_config = {}                     # guild_id -> {"channel_id": int, "message": str}
automod_config = {}                     # guild_id -> {"words": [...], "spam": bool, "mentions": bool, "invites": bool, "mention_threshold": int}
xp_data = {}                            # (guild_id, user_id) -> total xp
reaction_role_ids = set()               # role_ids with a live self-assign button (re-registered as views on startup)
temp_bans = {}                          # (guild_id, user_id) -> unban unix timestamp
antiraid_config = {}                    # guild_id -> {"enabled": bool, "threshold": int, "window": int}
case_counters = {}                      # guild_id -> last case number issued (warn/kick/ban/unban/mute/unmute/tempban/automod)
level_roles = {}                        # guild_id -> {level: role_id} (roles granted automatically at that level)
active_giveaways = {}                   # message_id -> {"guild_id","channel_id","host_id","winners","prize","ends_at","entrants":[user_ids]}
active_polls = {}                       # message_id -> {"guild_id","channel_id","host_id","host_name","question","options","votes":{user_id_str: idx},"ends_at"}

# --- Economy ---------------------------------------------------------------
# Server-local economy. Currency is Catnip; balances and inventory are persisted
# with the same Upstash/local storage system as the rest of Cinnamon.
economy_balances = {}                    # (guild_id, user_id) -> catnip
economy_inventory = {}                   # (guild_id, user_id) -> {item_id: quantity}
economy_quests = {}                      # (guild_id, user_id) -> {quest_id: progress, ...}
economy_cooldowns = {}                   # (guild_id, user_id, action) -> unix timestamp
economy_log_channels = {}                # guild_id -> channel_id
economy_level_rewards_claimed = {}        # (guild_id, user_id) -> [level numbers already rewarded]
economy_income_roles = {}                 # guild_id -> {role_id: {amount, cooldown}}

ECONOMY_ITEMS = {
    "tuna": {"name": "Tuna", "price": 25, "emoji": "🐟", "description": "A tasty tuna snack for Cinnamon.", "max_per_person": 0},
    "treat": {"name": "Cat Treat", "price": 15, "emoji": "🍪", "description": "A crunchy little reward.", "max_per_person": 0},
    "churu": {"name": "Churu", "price": 40, "emoji": "🥫", "description": "Premium lickable cat snack.", "max_per_person": 0},
    "catnip_ball": {"name": "Catnip Ball", "price": 60, "emoji": "🧶", "description": "Instant zoomies fuel.", "max_per_person": 0},
    "fish": {"name": "Fancy Fish", "price": 90, "emoji": "🐠", "description": "A fancy fish for a very fancy cat.", "max_per_person": 0},
}

ECONOMY_QUESTS = {
    "tuna_time": {"name": "Tuna Time", "item": "tuna", "amount": 3, "reward": 140, "description": "Give Cinnamon 3 tuna."},
    "treat_run": {"name": "Treat Run", "item": "treat", "amount": 5, "reward": 120, "description": "Give Cinnamon 5 cat treats."},
    "royal_snack": {"name": "Royal Snack", "item": "churu", "amount": 2, "reward": 130, "description": "Give Cinnamon 2 Churus."},
    "zoomies": {"name": "Zoomies", "item": "catnip_ball", "amount": 2, "reward": 180, "description": "Give Cinnamon 2 catnip balls."},
}
ECONOMY_ACHIEVEMENTS = {
    "first_feed": {"name": "First Snack", "description": "Feed Cinnamon an item for the first time.", "reward": 50},
    "quest_complete": {"name": "Quest Paw-sitive", "description": "Complete your first economy quest.", "reward": 100},
    "catnip_1000": {"name": "Catnip Hoarder", "description": "Reach 1,000 Catnip in your balance.", "reward": 150},
    "collector_10": {"name": "Snack Collector", "description": "Own at least 10 total economy items at once.", "reward": 100},
    "all_quests": {"name": "Cinnamon's Favorite", "description": "Complete every currently defined economy quest.", "reward": 300},
}
economy_achievements = {}             # (guild_id, user_id) -> set/list of unlocked achievement ids

ECONOMY_STARTING_BALANCE = 100
ECONOMY_DAILY_REWARD = 150
ECONOMY_WORK_MIN = 50
ECONOMY_WORK_MAX = 150
ECONOMY_WORK_COOLDOWN = 600  # 10 minutes
ECONOMY_LEVEL_REWARDS = {1: 100, 2: 200, 3: 350, 4: 600, 5: 1200, 10: 3000, 15: 5000}

# In-memory only (session state — fine to lose on restart):
afk_users = {}                          # (guild_id, user_id) -> reason
xp_cooldowns = {}                       # (guild_id, user_id) -> monotonic time of last XP award
spam_tracker = defaultdict(lambda: deque(maxlen=6))   # (guild_id, user_id) -> recent message timestamps
join_log = defaultdict(lambda: deque(maxlen=20))      # guild_id -> recent member-join timestamps (anti-raid)

# ---------------------------------------------------------------------------
# Gemini
# ---------------------------------------------------------------------------

gemini_client = genai.Client(api_key=GEMINI_API_KEY)


def ask_gemini(channel_id: int, speaker: str, trigger_text: str, guild: "discord.Guild | None") -> dict:
    """Blocking call to Gemini. Run this off the event loop with asyncio.to_thread.

    Returns {"reply": str, "reaction": str} where reaction is either a plain
    unicode emoji, the bare name of one of the guild's custom emoji (no colons),
    or "" if nothing fits.
    """
    history = channel_memories[channel_id]
    convo = "\n".join(f"{name}: {text}" for name, text in history)

    custom_emoji_names = [e.name for e in guild.emojis] if guild else []
    emoji_note = (
        f"This server also has these custom emoji you may react with by bare name "
        f"(no colons): {', '.join(custom_emoji_names)}."
        if custom_emoji_names else
        "This server has no custom emoji available, so only use a standard unicode emoji, or none."
    )

    prompt = (
        f"Recent channel conversation:\n{convo}\n\n"
        f"{speaker} just said: \"{trigger_text}\"\n\n"
        f"Reply as Cinnamon, talking to {speaker}. {emoji_note}\n\n"
        "Respond with ONLY a JSON object (no markdown fences, no extra text) shaped exactly like:\n"
        '{"reply": "<your in-character reply, 1-3 sentences>", '
        '"reaction": "<one unicode emoji, OR a bare custom emoji name from the list above, '
        'OR an empty string if none fits>"}'
    )

    response = gemini_client.models.generate_content(
        model=GEMINI_MODEL,
        contents=prompt,
        config=types.GenerateContentConfig(
            system_instruction=SYSTEM_PROMPT,
            max_output_tokens=200,
            temperature=0.9,
            response_mime_type="application/json",
        ),
    )

    raw = (response.text or "").strip()
    raw = re.sub(r"^```(?:json)?|```$", "", raw, flags=re.IGNORECASE).strip()

    reply, reaction = "", ""
    try:
        data = json.loads(raw)
        reply = str(data.get("reply") or "").strip()
        reaction = str(data.get("reaction") or "").strip()
    except (json.JSONDecodeError, AttributeError):
        reply = raw  # fall back to treating the whole thing as plain text

    if not reply:
        reply = "*blinks slowly, unsure what just happened*"
    return {"reply": reply, "reaction": reaction}


# ---------------------------------------------------------------------------
# Discord bot
# ---------------------------------------------------------------------------

intents = discord.Intents.default()
intents.message_content = True
intents.members = True  # needed for /role add-all and for finding the owner by username

bot = commands.Bot(command_prefix="?", intents=intents, case_insensitive=True, help_command=None)


# --- "Who's your owner / favorite person" ------------------------------------

_OWNER_QUESTION_PATTERNS = [
    re.compile(r"\bwho.{0,20}\bowner\b", re.IGNORECASE),
    re.compile(r"\bowner\b.{0,20}\bwho\b", re.IGNORECASE),
    re.compile(r"\b(favorite|favourite)\s+person\b", re.IGNORECASE),
    re.compile(r"\bwho\s+(made|created|owns|built)\s+you\b", re.IGNORECASE),
]


def is_owner_question(text: str) -> bool:
    return any(p.search(text) for p in _OWNER_QUESTION_PATTERNS)




# ---------------------------------------------------------------------------
# Modular feature loading
# ---------------------------------------------------------------------------
# Cinnamon remains ONE bot. The feature files are executed in this same
# namespace so cross-feature globals, decorators, command groups, storage,
# and callbacks keep working without changing the bot's architecture.

from pathlib import Path as _CINNAMON_PATH

_CINNAMON_MODULE_DIR = _CINNAMON_PATH(__file__).resolve().parent / "cinnamon_modules"
_CINNAMON_MODULES = (
    "core_events.py",
    "general_moderation.py",
    "dashboard_runtime.py",
    "moderation.py",
    "levels_games.py",
    "server_setup.py",
    "economy.py",
    "hangry_games.py",
)


def _load_cinnamon_module(filename: str) -> None:
    module_path = _CINNAMON_MODULE_DIR / filename
    if not module_path.is_file():
        raise FileNotFoundError(f"Missing Cinnamon module: {module_path}")
    source = module_path.read_text(encoding="utf-8")
    code = compile(source, str(module_path), "exec")
    exec(code, globals(), globals())


for _cinnamon_module in _CINNAMON_MODULES:
    _load_cinnamon_module(_cinnamon_module)

del _cinnamon_module

if __name__ == "__main__":
    threading.Thread(target=run_flask, daemon=True).start()
    bot.run(DISCORD_TOKEN)
