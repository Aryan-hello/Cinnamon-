# Cinnamon modular layout

Cinnamon is still one Discord bot and one Render process. `main.py` starts the bot and loads the feature files from `cinnamon_modules/` into the same Python runtime namespace.

## Files
- `main.py` — startup, configuration, shared state, Gemini client, bot creation, and module loader.
- `cinnamon_modules/core_events.py` — Gemini/AI events, logging helpers, prefix commands, message handling, and Discord event handlers.
- `cinnamon_modules/general_moderation.py` — pet commands, AI/log channel setup, moderation role commands, and app-command error handling.
- `cinnamon_modules/dashboard_runtime.py` — Flask dashboard runtime and persistence bridge.
- `cinnamon_modules/moderation.py` — warnings, welcome/goodbye, reaction roles, AutoMod, temp bans, and related moderation systems.
- `cinnamon_modules/levels_games.py` — XP/levels, giveaways, polls, and timers.
- `cinnamon_modules/server_setup.py` — anti-raid, lock/unlock, setup/help/status, category logs, and recovery commands.
- `cinnamon_modules/economy.py` — Catnip economy, shop, quests, achievements, income, snapshots, and recovery.
- `cinnamon_modules/hangry_games.py` — Hangry Games data and `HangryGamesCog`.

## Deployment
Render should continue running exactly:

```text
python main.py
```

Upload the entire project, including the `cinnamon_modules` folder. Do not upload only `main.py`.

The modular loader is intentionally conservative: it executes feature files in the same global namespace so Cinnamon keeps one bot, one command tree, one set of state dictionaries, and the same persistent data paths.


## Log recovery
`/recall` and `/datastatus recover` scan every distinct configured log channel (up to 2,000 messages per channel), report what they found, and restore only values supported by absolute log fields or a saved economy snapshot. Snapshot recovery fills missing accounts and fields instead of replacing live balances. XP uses the latest logged `XP after` value; completed quests and achievements are reconstructed only when the logs identify them. Events that were never logged or whose messages were deleted cannot be recovered.
